# test_helloworld_gc9a01.py
#
# Created: 17 October 2025
#
# Copyright (C) 2025 KW Services.
# MIT License
#
# Verified on:
# MicroPython v1.20.0-724-gbf1107420 on 2025-02-19;
# Raspberry Pi Pico with RP2040
# LVGL 9.1

import lvgl as lv
from machine import reset
from display_driver import disp 
import time
lv.init()

#### UI ####
scr = lv.obj()
lv.screen_load(scr)

red = lv.PALETTE.RED
blue = lv.PALETTE.BLUE
green = lv.PALETTE.GREEN

obj = lv.obj(scr)
obj.set_size(100,50)
obj.center()

lbl = lv.label(obj)
lbl.set_text("Hello")
lbl.set_style_text_font(lv.font_montserrat_24, lv.PART.MAIN)
lbl.center()

obj.set_style_bg_color(lv.palette_main(red), 0)


#### Run the event loop ####
# while True:
#     lv.timer_handler()
#     time.sleep_ms(10)
